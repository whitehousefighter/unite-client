package me.luna.trollhack.setting

import me.luna.trollhack.util.interfaces.Nameable

interface GenericConfigClass : Nameable