package me.luna.trollhack.module.modules.render

import me.luna.trollhack.module.Category
import me.luna.trollhack.module.Module

internal object AntiFog : Module(
    name = "AntiFog",
    description = "Disables or reduces fog",
    category = Category.RENDER
)