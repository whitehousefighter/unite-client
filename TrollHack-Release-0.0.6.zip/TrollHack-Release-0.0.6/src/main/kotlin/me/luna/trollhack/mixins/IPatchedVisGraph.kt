package me.luna.trollhack.mixins

interface IPatchedVisGraph {
    fun setOpaqueCube(x: Int, y: Int, z: Int)
}