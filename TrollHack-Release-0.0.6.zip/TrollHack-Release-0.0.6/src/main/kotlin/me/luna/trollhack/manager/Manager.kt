package me.luna.trollhack.manager

import me.luna.trollhack.event.AlwaysListening
import me.luna.trollhack.util.interfaces.Helper

abstract class Manager : AlwaysListening, Helper