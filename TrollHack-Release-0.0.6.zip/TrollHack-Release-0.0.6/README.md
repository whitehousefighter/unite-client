[//]: <> (Thanks for the advice KiLAB, now I'm going to ice out the README even more)
[//]: <> (Don't worry, these are comments, they won't actually show on the readme :)

[![Download button](https://img.shields.io/badge/client-download-success.svg)](https://github.com/Luna5ama/TrollHack/releases/download/Release-0.0.5/TrollHack-0.0.5.jar)
![Current version](https://img.shields.io/badge/version-0.0.5-blue)
# TrollHack
Strong hack

Discord server link: https://discord.gg/RFd2ugHC2S

# Note

MacOS is unsupported and will NOT be fixed since it is an Apple issue.


# FAQ
Before opening an issue, please consider the following:  
- Are you on the very latest version? In this case, it should be 0.0.5
- Did you compile it yourself, or did you use the release?
- Are your graphics drivers up to date?
- Are you using fast render? (If your version is below 0.0.5, you must upgrade to fix the fast render crash)  
If you're sure you've tried everything, open an issue. [How to ask a good question](https://stackoverflow.com/help/how-to-ask)

# Can't open the GUI?
- The default GUI key is **Y**, and the default chat command prefix is **;**
